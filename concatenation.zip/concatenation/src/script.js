function nameString(name){
	var b = "Edabit"
	var result = name+b
  	return result
}